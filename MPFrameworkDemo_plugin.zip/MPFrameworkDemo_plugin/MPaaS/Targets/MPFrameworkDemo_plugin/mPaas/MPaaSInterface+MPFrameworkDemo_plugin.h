//
//  MPaaSInterface+MPFrameworkDemo_plugin.h
//  MPFrameworkDemo_plugin
//
//  Created by vivi.yw on 2019/03/28.
//  Copyright © 2019 Alibaba. All rights reserved.
//

#import <mPaas/MPaaSInterface.h>

@interface MPaaSInterface (MPFrameworkDemo_plugin)

@end
