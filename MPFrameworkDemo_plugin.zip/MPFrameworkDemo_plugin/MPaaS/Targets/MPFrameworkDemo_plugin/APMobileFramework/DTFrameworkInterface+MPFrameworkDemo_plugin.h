//
//  DTFrameworkInterface+MPFrameworkDemo_plugin.h
//  MPFrameworkDemo_plugin
//
//  Created by vivi.yw on 2019/03/28.
//  Copyright © 2019 Alibaba. All rights reserved.
//

#import <APMobileFramework/DTFrameworkInterface.h>

@interface DTFrameworkInterface (MPFrameworkDemo_plugin)

@end
