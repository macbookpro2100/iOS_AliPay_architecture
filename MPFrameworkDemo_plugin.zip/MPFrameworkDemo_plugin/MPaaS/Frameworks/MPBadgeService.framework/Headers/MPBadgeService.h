//
//  MPBadgeService.h
//  MPBadgeService
//
//  Created by liangbao.llb on 12/9/14.
//  Copyright (c) 2014 Alipay. All rights reserved.
//

// 接口文件
#import <MPBadgeService/MPBadgeManager.h>
#import <MPBadgeService/MPBadgeServiceConfig.h>
#import <MPBadgeService/MPAbsBadgeView.h>
#import <MPBadgeService/MPBadgeView.h>
#import <MPBadgeService/MPBadgeInfo.h>
#import <MPBadgeService/MPWidgetInfo.h>