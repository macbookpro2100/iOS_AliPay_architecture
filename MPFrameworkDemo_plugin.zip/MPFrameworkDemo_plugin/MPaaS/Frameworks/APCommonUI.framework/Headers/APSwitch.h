//
//  APSwitch.h
//  APCommonUI
//
//  Created by 杨薇 on 15-4-9.
//  Copyright (c) 2015年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface APSwitch : UISwitch

@end
