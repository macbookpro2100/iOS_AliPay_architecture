



#import <AntUI/AUTextField.h>

__deprecated_msg("APTextFieldStyle 已经废弃，请尽快替换成 AUTextFieldStyle")
typedef AUTextFieldStyle APTextFieldStyle;

__deprecated_msg("APKeyboardType 已经废弃，请尽快替换成 AUKeyboardType")
typedef AUKeyboardType APKeyboardType;

__deprecated_msg("APTextField 已经废弃，请直接使用 AUTextField ")
@interface APTextField : AUTextField //UITextField

@end

@interface APTextFieldDelegateProxy : AUTextFieldDelegateProxy


@end
