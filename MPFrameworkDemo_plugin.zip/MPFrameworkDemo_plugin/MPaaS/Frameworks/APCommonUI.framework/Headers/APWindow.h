//
//  APWindow.h
//  APCommonUI
//
//  Created by liangbao.llb on 10/22/15.
//  Copyright © 2015 Alipay. All rights reserved.
//

#import <AntUI/AUWindow.h>

@interface APWindow : AUWindow

@end
