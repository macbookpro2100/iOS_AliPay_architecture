//
//  Masonry.h
//  Masonry
//
//  Created by Jonas Budelmann on 20/07/13.
//  Copyright (c) 2013 cloudling. All rights reserved.
//

#import <Foundation/Foundation.h>

__deprecated_msg("请直接使用 AntUI 中的masory，当前库文件已迁移")
#import <AntUI/Masonry.h>

