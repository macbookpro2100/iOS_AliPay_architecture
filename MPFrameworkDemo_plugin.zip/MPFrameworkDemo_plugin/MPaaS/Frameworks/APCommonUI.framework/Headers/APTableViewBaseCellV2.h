//
//  APTableViewBaseCellV2.h
//  APCommonUI
//
//  Created by Wang on 2018/9/20.
//  Copyright © 2018年 Alipay. All rights reserved.
//

#import <APCommonUI/APCommonUI.h>



@interface APTableViewCellV2 : APTableViewCell

@end

@interface APTableViewBaseCellV2 : APTableViewBaseCell

@end


