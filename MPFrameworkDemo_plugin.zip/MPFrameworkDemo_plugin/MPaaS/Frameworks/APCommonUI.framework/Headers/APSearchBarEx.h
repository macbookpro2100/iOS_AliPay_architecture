//
//  APSearchBarEx.h
//  APCommonUI
//
//  Created by majie on 15/7/16.
//  Copyright (c) 2015年 Alipay. All rights reserved.
//

#import "APSearchBar.h"

@interface APSearchBarEx : APSearchBar

@end
