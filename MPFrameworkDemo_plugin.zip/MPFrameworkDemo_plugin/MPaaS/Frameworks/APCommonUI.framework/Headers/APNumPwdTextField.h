//
//  APNumPwdTextField.h
//  APCommonUI
//
//  Created by liangbao.llb on 10/11/14.
//  Copyright (c) 2014 Alipay. All rights reserved.
//

#import "APTextField.h"

@interface APNumPwdTextField : AUTextField

@end
