//
//  APSegmentControlVisualStyle.h
//  APSegmentControl
//
//  Created by zikong on 14-1-22.
//  Copyright (c) 2014年 zikong. All rights reserved.
//

#import "APVisualStyle.h"

@interface APSegmentControlVisualStyle : APVisualStyle
@end
