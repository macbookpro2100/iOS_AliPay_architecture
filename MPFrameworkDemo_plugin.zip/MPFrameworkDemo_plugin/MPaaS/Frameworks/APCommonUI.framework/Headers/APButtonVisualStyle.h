//
//  APButtonVisualStyle.h
//  APCommonUI
//
//  Created by WenBi on 14-1-19.
//  Copyright (c) 2014年 WenBi. All rights reserved.
//

#import "APVisualStyle.h"

@interface APButtonVisualStyle : APVisualStyle

@end
