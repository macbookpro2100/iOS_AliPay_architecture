//
//  APToastDelegate.h
//  CommonUI
//
//  Created by  songdh on 14-1-6.
//  Copyright (c) 2014年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AntUI/AUToastDelegate.h>


__deprecated_msg("APToastDelegate已经废弃，请直接使用AUToastDelegate")
@protocol APToastDelegate <AUToastDelegate>
@end
