//
//  APIconLabel.h
//  a16
//
//  Created by majie on 14-12-30.
//  Copyright (c) 2014年 majie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AntUI/AUIconFont.h>

__deprecated_msg("APIconFont 已经废弃，请直接使用 AUIconFont")
@interface APIconFont : AUIconFont //NSObject

@end

