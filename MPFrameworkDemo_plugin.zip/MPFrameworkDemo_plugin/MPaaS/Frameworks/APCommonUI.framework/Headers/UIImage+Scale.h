//
//  UIImage+Scale.h
//  WealthTally
//
//  Created by Yanzhi on 15/2/5.
//  Copyright (c) 2015年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <AntUI/UIImage+Scale.h>
