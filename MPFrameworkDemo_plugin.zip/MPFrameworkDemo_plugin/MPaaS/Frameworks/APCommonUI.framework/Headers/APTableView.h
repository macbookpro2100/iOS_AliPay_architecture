//
//  APTableView.h
//  APCommonUI
//
//  Created by WenBi on 13-12-4.
//  Copyright (c) 2013年 WenBi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AntUI/AUTableView.h>

__deprecated_msg("APTableView 已经废弃，请直接使用 AUTableView")
@interface APTableView : UITableView

@end
