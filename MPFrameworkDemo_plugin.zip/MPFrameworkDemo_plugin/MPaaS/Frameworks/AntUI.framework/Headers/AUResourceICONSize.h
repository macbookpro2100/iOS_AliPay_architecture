//
//  AUResourceICONSize.h
//  AntUI
//
//  Created by maizhelun on 2016/9/25.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifndef AU_ICONSIZE_H
#define AU_ICONSIZE_H

extern CGSize   AU_ICONSIZE1;
extern CGSize   AU_ICONSIZE2;
extern CGSize   AU_ICONSIZE3;
extern CGSize   AU_ICONSIZE4;
extern CGSize   AU_ICONSIZE5;
extern CGSize   AU_ICONSIZE6;
extern CGSize   AU_ICONSIZE7;
extern CGSize   AU_ICONSIZE8;
extern CGSize   AU_ICONSIZE9;
extern CGSize   AU_ICONSIZE10;
extern CGSize   AU_ICONSIZE11;

extern void AU_DefineICONSize();

#endif
