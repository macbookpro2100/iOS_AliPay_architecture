#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_textfields//程序自动生成
//
//  AUNumPwdTextField.h
//  AntUI
//
//  Created by QiXin on 2016/9/29.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import "AUTextField.h"

@interface AUNumPwdTextField : AUTextField

@end

#endif//程序自动生成
