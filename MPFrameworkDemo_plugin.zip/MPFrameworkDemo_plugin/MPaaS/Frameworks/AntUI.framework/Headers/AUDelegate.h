#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_refreshLoadingView_AUDragLoadingView//程序自动生成
//
//  AUDelegate.h
//  AntUI
//
//  Created by maizhelun on 2017/6/26.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>

//@interface AUDelegate : NSObject <UIScrollViewDelegate, UITableViewDelegate>
//
//@property (nonatomic, strong) NSHashTable *extDelegateList;
//@property (nonatomic, weak) NSObject *originDelegate;
//
//@end

@interface NSObject (AUDelegate)
//
////- (BOOL)au_expandMethod:(SEL)expandSelector clazz:(Class)clazz;
////
////- (NSObject *)au_expandDelegate;
////- (void)au_setExpandDelegate:(NSObject *)delegate;
//
/////**
//// 对delegate进行扩展（可用于UIScrollView等）
////
//// @param delegate 扩展了delegate的对象
//// */
////- (void)au_addExtDelegate:(NSObject *)delegate;
////- (void)au_removeExtDelegate:(NSObject *)delegate;
//
@end

#endif//程序自动生成
