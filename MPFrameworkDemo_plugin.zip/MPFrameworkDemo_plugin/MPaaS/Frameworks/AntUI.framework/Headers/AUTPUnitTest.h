//
//  AUTPUnitTest.h
//  AntUI
//
//  Created by maizhelun on 2017/3/31.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#ifdef DEBUG

#import <Foundation/Foundation.h>

@interface AUTPUnitTest : NSObject

+ (void)run;

@end

#endif
