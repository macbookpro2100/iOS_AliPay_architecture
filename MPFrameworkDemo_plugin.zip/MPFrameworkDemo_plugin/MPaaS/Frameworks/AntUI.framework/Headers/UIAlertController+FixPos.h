//
//  UIAlertController+FixPos.h
//  APCommonUI
//
//  Created by myy on 15/4/16.
//  Copyright (c) 2015年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UIAlertController(FixPos)
@end