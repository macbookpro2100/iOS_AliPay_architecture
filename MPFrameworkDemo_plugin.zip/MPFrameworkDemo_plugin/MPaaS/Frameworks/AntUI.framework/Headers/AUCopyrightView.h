#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_BaseComponent_PageFooter//程序自动生成
//
//  AUCopyrightView.h
//  AntUI
//
//  Created by 莜阳 on 2017/6/21.
//  Copyright © 2017年 Alipay. All rights reserved.
//
#import "AULabel.h"

@interface AUCopyrightView : UIView

@property (nonatomic, strong) AULabel *copyrightLabel;

//
- (instancetype)initWithFrame:(CGRect)frame string:(NSString *)string;

@end

#endif//程序自动生成
