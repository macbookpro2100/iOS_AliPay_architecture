#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_actionSheet_AUActionSheet//程序自动生成
//
//  AUActionSheetCustomCell.h
//  AntUI
//
//  Created by zhaolei on 2017/6/23.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AUActionSheetItem;

@interface AUActionSheetCustomCell : UITableViewCell

- (void)reloadCell:(AUActionSheetItem *) item;

@end

#endif//程序自动生成
