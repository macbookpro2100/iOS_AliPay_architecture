#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_Tableview//程序自动生成
//
//  AUNLine.h
//  AntUI
//
//  Created by maizhelun on 2017/3/6.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AUNCssItemView.h"

@interface AUNLine : UIView

@property (nonatomic, strong) UIColor *color;

@end

#endif//程序自动生成
