//
//  APCommonUIImageGenerator.h
//  WealthTally
//
//  Created by Yanzhi on 15/2/5.
//  Copyright (c) 2015年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AUCommonUIImageGenerator : NSObject

+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size;

@end
