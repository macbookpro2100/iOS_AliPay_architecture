#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_BaseComponent_AUCollectionView//程序自动生成
//
//  AUCollectionView.h
//  AntUI
//
//  Created by maizhelun on 2017/6/28.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

AntUI_BaseComponent
@interface AUCollectionView : UICollectionView
@end

#endif//程序自动生成
