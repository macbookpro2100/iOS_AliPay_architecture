#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_amountInputBox_SimpleAmountInput//程序自动生成
//
//  AUAmountLabelText.h
//  AntUI
//
//  Created by zhaolei on 2017/6/20.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
 AUAmountEditTextField配套使用的金额显示组件.
 */
@interface AUAmountLabelText : UIView

@property (nonatomic, copy) NSString *amountText;//金额数字,不带羊角符号.比如:"80.01"

@end

NS_ASSUME_NONNULL_END

#endif//程序自动生成
