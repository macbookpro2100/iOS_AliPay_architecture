#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_alert_AUAuthorizeDialog//程序自动生成
//
//  AUULView.h
//  AntUI
//
//  Created by 沫竹 on 2017/11/29.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AUULView : UIView

@property (nonatomic, assign) CGFloat width;
@property (nonatomic, copy) NSArray *items;

@end

#endif//程序自动生成
