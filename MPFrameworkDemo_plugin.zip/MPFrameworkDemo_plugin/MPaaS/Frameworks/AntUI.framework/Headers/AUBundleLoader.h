//
//  AUBundleLoader.h
//  AntUI
//
//  Created by 莜阳 on 2017/6/26.
//  Copyright © 2017年 Alipay. All rights reserved.
//

@interface AUBundleLoader : NSObject

+(NSBundle *)themeBundleForName:(NSString *)bundleName;

@end
