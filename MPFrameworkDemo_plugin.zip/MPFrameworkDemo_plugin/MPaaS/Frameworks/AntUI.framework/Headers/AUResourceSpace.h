//
//  AUResourceSpace.h
//  AntUI
//
//  Created by maizhelun on 2016/9/25.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifndef AU_SPACE_H
#define AU_SPACE_H

extern CGFloat AU_SPACE1;
extern CGFloat AU_SPACE2;
extern CGFloat AU_SPACE3;
extern CGFloat AU_SPACE4;
extern CGFloat AU_SPACE5;
extern CGFloat AU_SPACE6;
extern CGFloat AU_SPACE7;
extern CGFloat AU_SPACE8;
extern CGFloat AU_SPACE9;
extern CGFloat AU_SPACE10;
extern CGFloat AU_SPACE11;
extern CGFloat AU_SPACE12;
extern CGFloat AU_SPACE13;
extern CGFloat AU_SPACE14;
extern CGFloat AU_SPACE15;
extern CGFloat AU_SPACE16;
extern CGFloat AU_SPACE17;
extern CGFloat AU_SPACE18;
extern CGFloat AU_SPACE19;
extern CGFloat AU_SPACE20;

extern CGFloat AU_DIVIDER_SPACE1;       // 1个像素
extern CGFloat AU_DIVIDER_SPACE2;       // 1个单位

extern void AU_DefineSpace();

#endif
