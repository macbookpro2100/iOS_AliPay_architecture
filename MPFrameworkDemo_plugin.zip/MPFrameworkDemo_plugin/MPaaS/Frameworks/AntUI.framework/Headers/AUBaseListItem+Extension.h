#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_Tableview//程序自动生成
//
//  AUNBaseListItem+Extension.h
//  AntUI
//
//  Created by 莜阳 on 17/3/7.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import "AUBaseListItem.h"
#import "AUNCssItemView.h"
#import "AUNListItemContainerView.h"

// 提供给内部用的扩展参数
@interface AUBaseListItem()

@property (nonatomic, strong) AUNCssItemView *cssItemView;
@property (nonatomic, strong) AUNListItemContainerView *containerView;
@property (nonatomic,strong) AUListItemModel* baseModel;

@end

#endif//程序自动生成
