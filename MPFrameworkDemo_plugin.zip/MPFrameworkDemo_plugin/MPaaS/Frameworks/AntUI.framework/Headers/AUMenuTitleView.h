#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_TitleBar_AUMenuTitleView//程序自动生成
//
//  AUMenuTitleView.h
//  AntUI
//
//  Created by 莜阳 on 2017/11/1.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

// 菜单显示titleView

@interface AUMenuTitleView : UIView

- (instancetype)initWithTitle:(NSString *)title;

- (void)setTitleText:(NSString *)text;

@end

#endif//程序自动生成
