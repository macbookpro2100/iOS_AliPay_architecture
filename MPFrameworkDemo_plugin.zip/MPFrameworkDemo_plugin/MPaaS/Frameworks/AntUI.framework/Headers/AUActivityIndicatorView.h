#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_BaseComponent_AUActivityIndicatorView//程序自动生成
//
//  AUActivityIndicatorView.h
//  AntUI
//
//  Created by maizhelun on 2016/9/29.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>


//#########################################################
//文档地址 : https://yuque.antfin-inc.com/antui/auidoc/ios_auactivityindicatorview
//#########################################################


AntUI_BaseComponent
@interface AUActivityIndicatorView : UIActivityIndicatorView

@end

#endif//程序自动生成
