#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_TitleBar_AUBarButtonItem//程序自动生成
//
//  AUBarButtonItem+AUExtendInfo.h
//  AntUI
//
//  Created by 莜阳 on 2017/6/7.
//  Copyright © 2017年 Alipay. All rights reserved.
//
#import "AUBarButtonItem.h"

@interface AUBarButtonItem (AUExtendInfo)

// 支付宝返回按钮默认是蓝色icon，独立App可修改返回按钮默认图标
+ (UIImage *)au_default_backButtonImg;

@end



#endif//程序自动生成
