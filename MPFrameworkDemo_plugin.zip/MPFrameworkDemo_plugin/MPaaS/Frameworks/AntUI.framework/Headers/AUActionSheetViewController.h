#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_actionSheet_AUActionSheet//程序自动生成
//
//  AUActionSheetViewController.h
//  AntUI
//
//  Created by QiXin on 2016/9/28.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AUActionSheet;

@interface AUActionSheetViewController : UIViewController
@property (weak, nonatomic) AUActionSheet *actionSheet;
@end


#endif//程序自动生成
