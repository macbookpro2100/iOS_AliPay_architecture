#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_Tableview_AUListSeparatorLine//程序自动生成
//
//  AUListSeparatorLine.h
//  AntUI
//
//  Created by 莜阳 on 2018/1/12.
//  Copyright © 2018年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AUListSeparatorLine : UIView

@end

#endif//程序自动生成
