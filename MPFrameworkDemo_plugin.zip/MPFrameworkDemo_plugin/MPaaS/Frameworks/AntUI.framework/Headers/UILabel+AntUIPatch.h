//
//  UILabel+AntUIPatch.h
//  AntUI
//
//  Created by maizhelun on 2017/4/12.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (AntUIPatch)

- (void)aui_setAttributedText:(NSAttributedString *)attributedText;

@end
