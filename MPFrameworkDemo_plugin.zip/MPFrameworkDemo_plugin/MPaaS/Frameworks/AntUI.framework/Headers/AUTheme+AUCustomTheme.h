//
//  AUTheme+AUCustomTheme.h
//  AntUI
//
//  Created by 莜阳 on 2017/6/23.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import "AUTheme.h"

@interface AUTheme ()

@property (nonatomic, strong) NSMutableDictionary *customThemeDic; // 业务定制化肤色值

@end
