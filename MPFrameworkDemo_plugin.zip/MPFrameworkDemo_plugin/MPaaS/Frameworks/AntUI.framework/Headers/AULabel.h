#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_BaseComponent_AULabel//程序自动生成
//
//  AULabel.h
//  AntUI
//
//  Created by maizhelun on 2016/9/30.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>


#import "AUScalingModel.h"
//#########################################################
//文档地址 : https://yuque.antfin-inc.com/antui/auidoc/ios_aulabel
//#########################################################


AntUI_BaseComponent

@interface UIView (AUScalingExtention)

@property (nonatomic,strong) AUScalingModel *au_scalingModel;


@property (nonatomic,strong) NSString *au_universeIdentifer;

@end

@interface AULabel : UILabel



@end

#endif//程序自动生成
