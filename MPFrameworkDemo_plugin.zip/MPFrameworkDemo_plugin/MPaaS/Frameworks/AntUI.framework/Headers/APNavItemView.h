#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_FloatMenu_AUFloatMenu//程序自动生成
//
//  APNavItemView.h
//  Launcher
//
//  Created by ronghui.zrh on 15/9/7.
//  Copyright (c) 2015年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AUNavItemView.h"

#define APNavItemPreferedIconSize  (CGSizeMake(21,21))

__deprecated_msg("APNavItemView 即将废弃，请直接使用 AUNavItemView")

@interface APNavItemView : AUNavItemView 

@end

#endif//程序自动生成
