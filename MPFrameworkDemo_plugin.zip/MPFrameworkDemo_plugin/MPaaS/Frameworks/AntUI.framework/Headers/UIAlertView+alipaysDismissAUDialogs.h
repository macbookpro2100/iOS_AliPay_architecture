#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_alert//程序自动生成
//
//  UIAlertView+DismissAUDialogs.h
//  AntUI
//
//  Created by 莜阳 on 17/3/3.
//  Copyright © 2017年 Alipay. All rights reserved.
//

// 兼容框架不依赖 AntUI 依然能清除所有弹窗的情况

@interface UIAlertView (alipaysDismissAUDialogs)

+ (void)alipaysDismissDialogs;

@end

#endif//程序自动生成
