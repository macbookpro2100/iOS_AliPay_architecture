//
//  NSThread+AUStackSympol.h
//  AntUI
//
//  Created by 莜阳 on 2017/5/23.
//  Copyright © 2017年 Alipay. All rights reserved.
//

@interface NSThread (AUStackSympol)

+ (NSString*)AntUICallStackString;

@end
