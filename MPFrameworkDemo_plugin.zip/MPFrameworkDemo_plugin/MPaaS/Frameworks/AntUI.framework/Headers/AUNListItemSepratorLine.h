#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_Tableview//程序自动生成
//
//  AUNListItemSepratorLine.h
//  AntUI
//
//  Created by maizhelun on 2017/2/28.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AUNListItemSepratorLine : UIView

@property (nonatomic, assign) CGFloat    AUN_left;
@property (nonatomic, assign) CGFloat    AUN_right;
@property (nonatomic, assign) CGFloat    AUN_height;

@property (nonatomic, strong) UIColor   *AUN_color;

@end

#endif//程序自动生成
