#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_amountInputBox//程序自动生成
//
//  AUAmountEditTextFieldFormatDelegate.h
//  AntUI
//
//  Created by zhaolei on 2017/9/20.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AUAmountEditTextFieldFormatDelegate : NSObject <UITextFieldDelegate>

@end

#endif//程序自动生成
