#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_Tableview//程序自动生成
//
//  AUNTwoSegmentLabel.h
//  AntUI
//
//  Created by maizhelun on 2017/3/3.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AUNTwoSegmentLabel : UILabel

@property (nonatomic, strong) NSString *text1;
@property (nonatomic, strong) NSString *text2;

@end

#endif//程序自动生成
