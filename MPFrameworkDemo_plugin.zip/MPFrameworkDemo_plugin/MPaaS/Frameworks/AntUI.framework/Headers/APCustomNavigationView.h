#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_TitleBar_AUCustomNavigationBar//程序自动生成
//
//  APCustomNavigationView.h
//  APExtUI
//
//  Created by yangwei on 16/6/1.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <AntUI/AUCustomNavigationBar.h>

__deprecated_msg("APCustomNavigationView 已经废弃，请直接使用 AUCustomNavigationBar")
@interface APCustomNavigationView : AUCustomNavigationBar //UIView

+ (APCustomNavigationView *)customNavigatorViewWithCurrentVC:(UIViewController *)currentVC;

@end


#endif//程序自动生成
