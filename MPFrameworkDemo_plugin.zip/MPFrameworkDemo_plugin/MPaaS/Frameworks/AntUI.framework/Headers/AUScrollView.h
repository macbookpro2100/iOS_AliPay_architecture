#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_BaseComponent_AUScrollView//程序自动生成
//
//  AUScollView.h
//  AntUI
//
//  Created by maizhelun on 2017/6/27.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

AntUI_BaseComponent
@interface AUScrollView : UIScrollView

@end

#endif//程序自动生成
