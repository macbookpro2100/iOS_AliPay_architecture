#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_amountInputBox_SimpleAmountInput//程序自动生成
//
//  AUMoneyIconView.h
//  AntUI
//
//  Created by zhaolei on 2017/6/20.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AUMoneyIconView : UIView

@property(nonatomic,assign) CGFloat fontSize;
@property(nonatomic,assign) CGFloat rightPadding;

@end

#endif//程序自动生成
