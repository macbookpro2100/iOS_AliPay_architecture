//
//  AUShellPlugIn.h
//  AntUI
//
//  Created by 祝威 on 16/12/8.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 ANTUI shell 第三方插件
 */
@interface AUShellThirdPlugIn : NSObject


/**
 加载shell 的第三方插件
 */
+ (void) loadShellThirdPlugIn ;

@end
