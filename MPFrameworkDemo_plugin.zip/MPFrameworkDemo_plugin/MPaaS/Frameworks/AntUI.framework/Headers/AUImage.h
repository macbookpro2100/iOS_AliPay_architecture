#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_BaseComponent_AUImage//程序自动生成
//
//  AUImage.h
//  AntUI
//
//  Created by maizhelun on 2016/10/13.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>



//#########################################################
//文档地址 : https://yuque.antfin-inc.com/antui/auidoc/ios_auimage
//#########################################################


AntUI_BaseComponent
@interface AUImage : UIImage

@end

#endif//程序自动生成
