#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_BaseComponent_AUWindow//程序自动生成
//
//  AUWindow.h
//  AntUI
//
//  Created by 祝威 on 16/9/26.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>



/*！
 @class       AUWindow
 @abstract    UIWindow
 @discussion  蚂蚁的window
 */
AntUI_BaseComponent
@interface AUWindow : UIWindow

@end

#endif//程序自动生成
