#import "AUUILoadDefine.h"//程序自动生成
#ifdef ANTUI_UI_BaseComponent_AUSwitch//程序自动生成
//
//  AUSwitch.h
//  AntUI
//
//  Created by maizhelun on 2016/9/26.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>


//#########################################################
//文档地址 : https://yuque.antfin-inc.com/antui/auidoc/ios_auswitch
//#########################################################


AntUI_BaseComponent
@interface AUSwitch : UISwitch

@end

#endif//程序自动生成
